#!/bin/sh
while true; do
  ./Login </dev/null 1>/dev/null 2>&1
  sleep 1
done

